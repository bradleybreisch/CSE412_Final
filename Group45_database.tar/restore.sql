--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Homebrew)
-- Dumped by pg_dump version 17.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "CSE412_Project";
--
-- Name: CSE412_Project; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "CSE412_Project" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


\connect "CSE412_Project"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.book (
    isbn bigint NOT NULL,
    publication_year integer,
    author character varying(128),
    title character varying(256) NOT NULL,
    img_link text
);


--
-- Name: favorite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite (
    uid integer NOT NULL,
    isbn bigint NOT NULL,
    date_saved date
);


--
-- Name: listing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing (
    retailerid integer NOT NULL,
    isbn bigint NOT NULL,
    cost numeric(5,2),
    available boolean NOT NULL
);


--
-- Name: purchase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase (
    uid integer NOT NULL,
    isbn bigint NOT NULL
);


--
-- Name: retailer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailer (
    retailerid integer NOT NULL,
    name character varying(64),
    link text,
    phone_number bigint
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    uid integer NOT NULL,
    username character varying(64) NOT NULL,
    email character varying(64) NOT NULL,
    fname character varying(32) NOT NULL,
    lname character varying(32) NOT NULL,
    password character varying(64) NOT NULL
);


--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.book (isbn, publication_year, author, title, img_link) FROM stdin;
\.
COPY public.book (isbn, publication_year, author, title, img_link) FROM '$$PATH$$/3721.dat';

--
-- Data for Name: favorite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.favorite (uid, isbn, date_saved) FROM stdin;
\.
COPY public.favorite (uid, isbn, date_saved) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: listing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing (retailerid, isbn, cost, available) FROM stdin;
\.
COPY public.listing (retailerid, isbn, cost, available) FROM '$$PATH$$/3725.dat';

--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase (uid, isbn) FROM stdin;
\.
COPY public.purchase (uid, isbn) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: retailer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailer (retailerid, name, link, phone_number) FROM stdin;
\.
COPY public.retailer (retailerid, name, link, phone_number) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (uid, username, email, fname, lname, password) FROM stdin;
\.
COPY public.users (uid, username, email, fname, lname, password) FROM '$$PATH$$/3720.dat';

--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (isbn);


--
-- Name: favorite favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT favorite_pkey PRIMARY KEY (uid, isbn);


--
-- Name: listing listing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_pkey PRIMARY KEY (retailerid, isbn);


--
-- Name: purchase purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_pkey PRIMARY KEY (uid, isbn);


--
-- Name: retailer retailer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailer
    ADD CONSTRAINT retailer_pkey PRIMARY KEY (retailerid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (uid);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: favorite favorite_isbn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT favorite_isbn_fkey FOREIGN KEY (isbn) REFERENCES public.book(isbn);


--
-- Name: favorite favorite_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite
    ADD CONSTRAINT favorite_uid_fkey FOREIGN KEY (uid) REFERENCES public.users(uid);


--
-- Name: listing listing_isbn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_isbn_fkey FOREIGN KEY (isbn) REFERENCES public.book(isbn);


--
-- Name: listing listing_retailerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_retailerid_fkey FOREIGN KEY (retailerid) REFERENCES public.retailer(retailerid);


--
-- Name: purchase purchase_isbn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_isbn_fkey FOREIGN KEY (isbn) REFERENCES public.book(isbn);


--
-- Name: purchase purchase_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_uid_fkey FOREIGN KEY (uid) REFERENCES public.users(uid);


--
-- PostgreSQL database dump complete
--

